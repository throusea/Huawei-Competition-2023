import myutil
from robot import Robot
from robot import RobotState
from edge import Edge
from workbench import Workbench
from path_planning import PathPlanning
from robot_control import RobotControl


class MyListenser:

    def __init__(self, plan: PathPlanning):
        self.plan = plan
        self.rob: [Robot] = self.plan.get_robots()
        self.bench: [Workbench] = self.plan.get_workbenches()
        self.near = [0, 0, 0, 0]
        # self.date = open("date.txt", "w")
        self.frame = 0

    def check_dis(self, rob: Robot, bench: Workbench):
        dis: float = myutil.dist(rob.pos, bench.pos)
        v: float = 0.12
        t: float = dis / v
        if (t >= bench.status) and (bench.status != -1):
            return True
        else:
            return False

    def change_robot_command(self, rc: RobotControl, rob: Robot, edge: Edge, near: int):
        if rob.state == RobotState.IDLE:
            if edge == None:
                return 0
            if edge.fo.output == 1:
                rob.state = RobotState.TAKING
                return edge.fo.id
            else:
                rob.state = RobotState.TAKING
                return edge.fo.id
        elif rob.state == RobotState.TAKING:
            if rob.itemId == 0 and near == edge.fo.id:
                rc.buy(rob)

            if rob.itemId != 0:
                rob.state = RobotState.DELIVERING
                self.plan.unlock_first(rob, int(self.frame))
                # if rob.last_w != None:
                #     self.date.write(str.format("update from bench %d to bench %d: %f\n" % (rob.last_w.id, rob.loadingTask.fo.id, self.plan.graph.get_predict_tasktime(rob.last_w, rob.loadingTask.fo))))
                rob.last_w = edge.fo
                return edge.to.id
        else:
            if rob.itemId != 0 and near == edge.to.id:
                rc.sell(rob)

            if rob.itemId == 0:
                rob.state = RobotState.IDLE
                self.plan.unlock(rob, int(self.frame))
                # if rob.last_w != None:
                #     self.date.write(str.format("update from bench %d to bench %d: %f\n" % (rob.last_w.id, rob.loadingTask.to.id, self.plan.graph.get_predict_tasktime(rob.last_w, rob.loadingTask.to))))
                rob.last_w = edge.to
                rob.loadingTask = None
                return 0

    def collect(self):
        s = input()
        num_bench = int(s)

        for i in range(0, num_bench):
            s = input()
            s = s.split(' ')

            type = s[0]
            ben_pos: tuple = (s[1], s[2])
            self.bench[i].status = int(s[3])
            self.bench[i].inputs = int(s[4])
            self.bench[i].output = int(s[5])

        for i in range(0, 4):
            s = input()
            s = s.split(' ')

            self.near[i] = int(s[0])
            self.rob[i].itemId = int(s[1])
            self.rob[i].w = float(s[4])
            self.rob[i].vel = (float(s[5]) ** 2 + float(s[6]) ** 2) ** 0.5
            self.rob[i].rot = float(s[7])
            self.rob[i].pos = (float(s[8]), float(s[9]))



    def check_EOF(self):
        try:
            s = input()
            s = s.split()
            self.frame = s[0]
            return True
        except EOFError:
            return False
    def interact(self):
        rc = RobotControl()
        if not self.check_EOF():
            return False
        self.collect()
        print(self.frame)
        target = [0]
        for i in range(0, 4):
            target.append(self.change_robot_command(rc, self.rob[i], self.rob[i].loadingTask, self.near[i]))

        #col = rc.collision_predict(self.rob)
        occ = [False, False, False, False]

        """for i in range(0, 4):
            for j in range(i + 1, 4):
                if col[i][j]:
                    occ[i] = True
                    occ[j] = True
                    rc.collision_avoid(self.rob[i], self.rob[j])"""

        for i in range(0, 4):
            if not occ[i]:
                rc.forward(self.rob[i], self.rob)

        # self.date.write(str("Frame:%s\n"%(self.frame)))
        # self.date.write(str(self.near)+"\n")
        # for i in range(0, 4):
            # self.date.write(str(self.rob[i]) + "\n")

        # for i in range(0, len(self.bench)):
        #     self.date.write(str(self.bench[i]) + "\n")
        # self.date.write(str(self.plan.graph.q))
        # self.date.write("\n")


        # self.plan.update_idle_queue(self.frame)
        self.plan.allocate_rob(int(self.frame))
        #self.date.flush()

        return True

    def init_data(self):
        cnt_rob = -1
        cnt_ben = -1

        for i in range(1, 101):
            inp = input()
            for j in range(1, 101):
                c = inp[j - 1]
                if c == 'A':
                    cnt_rob += 1
                    new_rob = Robot(cnt_rob, (float(j - 1) * 0.5 + 0.25, 50 - 0.25 - float(i - 1) * 0.5))
                    self.rob.append(new_rob)
                    # print(str(new_rob.id)+" "+str(new_rob.pos[0])+" "+str(new_rob.pos[1]))
                elif c == '.':
                    pass
                else:
                    cnt_ben += 1
                    new_ben = Workbench(cnt_ben, int(c), (float(j - 1) * 0.5 + 0.25, 50 - 0.25 - float(i - 1) * 0.5))
                    self.bench.append(new_ben)

        self.plan.init_task()
        pass

    """def close_file(self):
        self.date.close()
        pass"""