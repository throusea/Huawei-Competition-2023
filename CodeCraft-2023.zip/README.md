# Huawei-Compeition
This is a team project of huawei chanllenge competition.
